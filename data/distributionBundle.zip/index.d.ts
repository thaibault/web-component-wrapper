import { Mapping } from 'clientnode/type';
import ReactWebImport from './React';
import WebImport from './Web';
import { ComponentType, WebComponentAPI, WebComponentConfiguration } from './type';
export declare const ReactWeb: typeof ReactWebImport;
export declare const reactWebAPI: WebComponentAPI<typeof ReactWebImport>;
export declare const webAPI: WebComponentAPI<typeof WebImport>;
export declare const Web: typeof WebImport;
/**
 * Wraps given react component as web component.
 * @param component - React component to wrap.
 * @param nameHint - A name to set as property in runtime generated web
 * component class.
 * @param configuration - Additional web component configurations.
 *
 * @returns Generated object to register and retrieve generated web component.
 */
export declare const wrapAsWebComponent: <Type extends ComponentType<Mapping<unknown>> = ComponentType<Mapping<unknown>>, ExternalProperties extends Mapping<unknown> = Mapping<unknown>, InternalProperties extends Mapping<unknown> = Mapping<unknown>, EventParameters extends unknown[] = unknown[]>(component: Type, nameHint?: string, configuration?: WebComponentConfiguration<ExternalProperties, InternalProperties, EventParameters>) => WebComponentAPI<typeof ReactWeb>;
export default wrapAsWebComponent;
