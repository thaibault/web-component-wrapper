/// <reference types="react" />
import { Mapping } from 'clientnode/type';
import ReactWebImport from './React';
import WebImport from './Web';
import { AttributesReflectionConfiguration, ComponentType, EventToPropertyMapping, PropertiesConfiguration, WebComponentAPI, WebComponentConfiguration } from './type';
export declare const ReactWeb: typeof ReactWebImport;
export declare const reactWebAPI: WebComponentAPI<HTMLElement, Mapping<unknown>, import("./type").ReactComponentBaseProperties<HTMLElement>, typeof ReactWebImport>;
export declare const webAPI: WebComponentAPI<HTMLElement, Mapping<unknown>, Mapping<unknown>, typeof WebImport>;
export declare const Web: typeof WebImport;
/**
 * Wraps given react component as web component.
 * @param component - React component to wrap.
 * @param nameHint - A name to set as property in runtime generated web
 * component class.
 * @param configuration - Additional web component configurations.
 *
 * @returns Generated object to register and retrieve generated web component.
 */
export declare const wrapAsWebComponent: <Type extends ComponentType<Mapping<unknown>> = ComponentType<Mapping<unknown>>, ExternalProperties extends Mapping<unknown> = Mapping<unknown>, InternalProperties extends Mapping<unknown> = Mapping<unknown>, EventParameters extends unknown[] = unknown[]>(component: Type, nameHint?: string, configuration?: WebComponentConfiguration<ExternalProperties, InternalProperties, EventParameters>) => WebComponentAPI<Type, ExternalProperties, InternalProperties, {
    new (): ReactWebImport<Type, ExternalProperties, InternalProperties>;
    attachWebComponentAdapterIfNotExists: boolean;
    content: string | ComponentType<Mapping<unknown>>;
    react: typeof import("react");
    _name: string;
    isReactComponent(domNode: Node): boolean;
    removeKnownUnwantedPropertyKeys(target: typeof ReactWebImport, properties: Mapping<unknown>): void;
    applyRootBinding: boolean;
    determineRootBinding: boolean;
    shadowDOM: boolean | {
        delegateFocus?: boolean | undefined;
        mode: "closed" | "open";
    } | null;
    observedAttributes: string[];
    controllableProperties: string[];
    eventToPropertyMapping: EventToPropertyMapping<Mapping<unknown>, Mapping<unknown>, unknown[]> | null;
    propertyAliases: Mapping<string>;
    propertyTypes: PropertiesConfiguration;
    propertiesToReflectAsAttributes: AttributesReflectionConfiguration;
    renderProperties: string[];
    cloneSlots: boolean;
    evaluateSlots: boolean;
    renderSlots: boolean;
    trimSlots: boolean;
    renderUnsafe: boolean;
    _propertyAliasIndex: Mapping<string> | undefined;
    _propertiesToReflectAsAttributes: import("./type").NormalizedAttributesReflectionConfiguration;
    replaceDomNodes(domNode: HTMLElement, children: Node | Node[]): void;
    unwrapDomNode(domNode: HTMLElement): ChildNode[];
    hasCode(content: unknown): boolean;
    normalizePropertyTypeList(value: AttributesReflectionConfiguration): import("./type").NormalizedAttributesReflectionConfiguration;
}>;
export default wrapAsWebComponent;
